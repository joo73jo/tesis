import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonContent,
  IonGrid,
  IonRow,
  IonCol,
  IonCard,
  AlertController
} from '@ionic/angular/standalone';
import { CalificacionesEstudianteService } from './calificaciones-estudiante.service';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-calificaciones-estudiante',
  standalone: true,
  templateUrl: './calificaciones-estudiante.page.html',
  styleUrls: ['./calificaciones-estudiante.page.scss'],
  imports: [
    CommonModule,
    IonContent,
    IonGrid,
    IonRow,
    IonCol,
    IonCard
  ],
})
export class CalificacionesEstudiantePage implements OnInit {

  calificaciones: any[] = [];
  nombreUsuario = '';

  constructor(
    private calificacionesService: CalificacionesEstudianteService,
    private authService: AuthService,
    private alertController: AlertController
  ) {}

  ngOnInit() {
    this.authService.user$.subscribe({
      next: (user) => {
        if (!user) {
          console.error('Usuario no autenticado');
          return;
        }

        this.nombreUsuario = `${user.nombres} ${user.apellidos}`;

        this.calificacionesService
          .getCalificacionesEstudiante(user._id)
          .subscribe({
            next: (data) => {
              this.calificaciones = data;
              console.log('CALIFICACIONES:', data);
            },
            error: (err) => {
              console.error('Error al obtener calificaciones', err);
            }
          });
      }
    });
  }

  async mostrarObservacion(nota: any) {
    const alert = await this.alertController.create({
      header: nota.curso || 'Observación',
      message: nota.observacion || 'Sin observación registrada.',
      buttons: ['OK'],
    });
    await alert.present();
  }
}
